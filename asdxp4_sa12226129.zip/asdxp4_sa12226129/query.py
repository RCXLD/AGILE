import database
import model

bands = database.db_session.query(model.Band).join(model.Album).filter(model.Album.Label == 'Warp')

print [band.Name for band in bands]

bands = database.db_session.query(model.Band).join(model.Album).join(model.Track).filter(model.Track.Name == 'Into the Rainbow Vein')

print [band.Name for band in bands]
