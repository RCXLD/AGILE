from sqlalchemy.orm.exc import NoResultFound

import database
import model

database.db_init()

for line in open('bands.txt'):
	obj=line.split(',')
	band = model.Band(obj[0],obj[1],obj[2],obj[4])
	genre = list(obj[3].split(';'))
	for i in genre:
		try:
			gen = database.db_session.query(model.Genre).filter(model.Genre.Name == i).one()
		except NoResultFound:
			gen = model.Genre(i)
			database.db_session.add(gen)
	band.Genres.append(gen)
	database.db_session.add(band)

for line in open('albums.txt'):
	obj=line.split(',')
	name  = obj[0]
	year  = obj[1]
	label = obj[2]
	band_name = obj[3]
	track_name = obj[4]
	track_duration = obj[5].rstrip()
	band = database.db_session.query(model.Band).filter(model.Band.Name == band_name).one()
	track = model.Track(track_name, track_duration)
	database.db_session.add(track)
	
	album = model.Album(name, year, label)
	album.TrackID = track
	database.db_session.add(album)
	
	band.Albums.append(album)
	
database.db_session.commit()
